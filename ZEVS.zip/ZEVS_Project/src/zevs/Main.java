package zevs;


import zevs.authorization.Authorization;

public class Main {

	public static void main(String[] args) {
	Authorization window = new Authorization();
	window.initialize();
		
		
	}

}
